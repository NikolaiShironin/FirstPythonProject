cnt = 0
while True:
    temp = float(input('>> '))
    if temp >= 23.0:
        break
    cnt += 1
print(cnt // 7)
