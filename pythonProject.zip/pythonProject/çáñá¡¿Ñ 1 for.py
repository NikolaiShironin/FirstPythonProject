a = 5
for i in range(a, -1, -1):
    print('Осталось секунд:', i)
print('Пуск')
