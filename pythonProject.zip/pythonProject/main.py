# Задание1while
a = 5
while a != -1:
    print('Осталось секунд:', a)
    a -= 1
print('Пуск')
