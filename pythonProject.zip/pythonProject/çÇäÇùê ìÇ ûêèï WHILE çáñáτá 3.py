v = None
result = 0
discount = 0.05
start_discount = 1000
while True:
    v = float(input())
    if v == -1.0:
        break
    else:
        result += v if v <= start_discount else v - v * discount
print(result)
