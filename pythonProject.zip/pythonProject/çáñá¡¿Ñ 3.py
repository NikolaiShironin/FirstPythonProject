n = int(input())
iq = int(input())
print(0)
for i in range(1, n + 1):
    b = int(input())
    if b > iq:
        print('>')
    elif b < iq:
        print('<')
    else:
        print(0)
    iq = (iq * i + b) / (i + 1)
